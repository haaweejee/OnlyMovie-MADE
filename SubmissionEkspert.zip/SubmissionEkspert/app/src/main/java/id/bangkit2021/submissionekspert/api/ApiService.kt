package id.bangkit2021.submissionekspert.api


import id.bangkit2021.submissionekspert.BuildConfig
import id.bangkit2021.submissionekspert.core.data.remote.response.MovieResponse
import retrofit2.http.GET
import retrofit2.http.Query

interface ApiService {
    @GET("discover/movie")
    suspend fun getMovieData(
        @Query("api_key") apiKey: String = BuildConfig.TMDB_TOKEN,
        @Query("language") language: String= BuildConfig.ENGLISH_US,
        @Query("page") page: Int = 1
    ): MovieResponse
}