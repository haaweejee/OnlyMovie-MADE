package id.bangkit2021.submissionekspert.core.data.remote.response

data class MovieModel(
        var id: Int,
        var poster_path : String,
        var original_title: String,
        var release_date: String,
        var overview: String,
        var backdrop_path: String,
)
