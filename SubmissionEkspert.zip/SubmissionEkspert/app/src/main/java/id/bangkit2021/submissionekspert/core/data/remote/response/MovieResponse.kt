package id.bangkit2021.submissionekspert.core.data.remote.response

data class MovieResponse(
    val results: List<MovieModel>
)
