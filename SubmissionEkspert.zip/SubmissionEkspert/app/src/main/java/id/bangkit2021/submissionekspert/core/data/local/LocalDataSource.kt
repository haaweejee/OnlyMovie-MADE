package id.bangkit2021.submissionekspert.core.data.local

import id.bangkit2021.submissionekspert.core.data.local.entity.MovieEntity
import id.bangkit2021.submissionekspert.core.data.local.room.MovieDao
import kotlinx.coroutines.flow.Flow

class LocalDataSource(private val movieDao: MovieDao){

    fun getMovieList() : Flow<List<MovieEntity>> = movieDao.getMovieList()

    fun getFavoriteMovie() : Flow<List<MovieEntity>> = movieDao.getFavoriteMovie()

    suspend fun insertMovie(movieEntity: List<MovieEntity>)  = movieDao.insertMovies(movieEntity)

    fun setFavoriteMovie(movieEntity: MovieEntity, favorite : Boolean){
        movieEntity.favorite = favorite
        movieDao.updateMovies(movieEntity)
    }
}